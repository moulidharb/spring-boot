package com.example.college;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;
@RequestMapping("/colleges")
@RestController
public class CollegeController {
    private List<College> Colleges = Arrays.asList(
            new College(101, "MSRIT","Mattikere" ),
            new College(201, "RV", "Pattangere"),
            new College(301, "BMS","Basvangudi"));
    
    @GetMapping
    public List<College> getAllColleges() {
        return Colleges;
    }
    
    @GetMapping("/{id}")
    public College getCollegeById(@PathVariable int id) {
        return Colleges.stream()
                        .filter(College -> College.getId() == id)
                        .findFirst()
                        .orElseThrow(IllegalArgumentException::new);
    }
}
