package com.example.student;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import java.util.Arrays;
import java.util.List;
@RequestMapping("/students")
@RestController
public class StudentController {
    private final List<Student> Students = Arrays.asList(
            new Student(1, 101, "Pramod"),
            new Student(2, 101, "Pratik"),
            new Student(3, 201, "Prakash"),
            new Student(4, 301, "Nandan"),
            new Student(5, 201, "Piyush"));

    @GetMapping
    public List<Student> getAllStudents() {
        return Students;
    }

    @GetMapping("/{id}")
    public Student getStudentById(@PathVariable int id) {
        return Students.stream()
                     .filter(Student -> Student.getId() == id)
                     .findFirst()
                     .orElseThrow(IllegalArgumentException::new);
    }
}
